import json
from abc import ABCMeta, abstractmethod
from tornado.ioloop import IOLoop
from tornado import gen
from mg_app_framework.config import Store, get_logger, set_handler, get_handler, get_uuid, get_organization
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task
from inspect import iscoroutinefunction


class RabbitMQConfigBasic(metaclass=ABCMeta):
    @abstractmethod
    def get_rabbitmq_host(self):
        pass

    @abstractmethod
    def get_rabbitmq_port(self):
        pass

    @abstractmethod
    def get_rabbitmq_username(self):
        pass

    @abstractmethod
    def get_rabbitmq_password(self):
        pass

    def publish_config_data(self):
        """
        :return:True  -> 表示需要发布配置数据
                False -> 表示不需要发布配置数据
        """
        return False

    def get_rabbitmq_subscribe_list(self):
        """
        :return:返回订阅的数组
        [
            'kkk', # 消息索引
            'yyy', # 消息索引
            ...
        ]
        """
        return []

    @abstractmethod
    def messsge_process_func(self):
        """
        1. subscribe_list is not empty
        2. when receive message, call this function to process message
        message 数据格式:
        {
            'key'  : 'kkk',  # 消息索引
            'data' : {}      # 消息数据
        }
        # 消息处理函数:
        def rabbitmq_message_func_examlple(message):
            if msg['key'] == 'kkk':
                get_logger().info("msg: %s" % (str(message)))
            elif msg['key'] == 'yyy':
                get_logger().info("msg: %s" % (str(message)))

        :return:返回处理函数名(rabbitmq_message_func_examlple)
        """
        pass

    def reconnect_interval(self):
        """
        :return:重连rabbitmq时间间隔, 默认 5 秒

        """
        return 5


class RabbitMQClient:
    def __init__(self, host, port, username, password, topic_name, queue_name, subscribe_list,
                 publish_config_data, reconnect_interval, messsge_process_func=None):

        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.topic_name = topic_name
        self.queue_name = queue_name
        self.subscribe_list = subscribe_list
        self.publish_config_data = publish_config_data
        self.connection = None
        self.channel = None
        self.queue = None  # 一个app对应一个持久化队列
        self.topic = {}
        self.subscribe_message_cache = {}
        self.publish_message_cache = {}
        self.reconnect_interval = reconnect_interval
        self.messsge_process_func = messsge_process_func
        self.local_mongodb_connection = None

    async def get_connection(self):
        # get rabbitmq connection ,if not exist create one
        from aio_pika import connect as aio_pika_connect
        if not self.connection:
            try:
                self.connection = await aio_pika_connect(host=self.host, port=self.port, login=self.username,
                                                         password=self.password)
                self.connection.add_close_callback(self.on_connection_closed)
                get_logger().info('connect rabbitmq success')
            except:
                get_logger().error('connect rabbitmq failed, [host=%s],[port=%s],[username=%s],[password=%s]',
                                   self.host, self.port, self.username, self.password)
        return self.connection

    async def create_channel(self):
        # create rabbitmq channel ,if not exist create one
        if self.connection:
            self.channel = await self.connection.channel()
            get_logger().info('create rabbitmq channel success')
        return self.channel

    async def create_topic(self, topic_name):
        # create topic_type exchange with given topic_name
        from aio_pika import ExchangeType
        if self.channel and topic_name:
            exchange = await self.channel.declare_exchange(topic_name, ExchangeType.TOPIC)
            self.topic.update({topic_name: exchange})
            get_logger().info('create topic[%s] success', topic_name)
            return exchange

    async def get_topic(self, topic_name):
        # get the topic_type exchange with given topic_name, if not exist create one
        exchange = self.topic.get(topic_name)
        if exchange is None:
            exchange = await self.create_topic(topic_name)
            self.topic.update({topic_name: exchange})

        get_logger().debug('get topic[%s] success', topic_name)
        return exchange

    async def init_topic_and_queue(self):
        # create channel\topic\queue,and bind topic exchange with subscribe_list
        get_logger().info('start rabbitmq init process')
        await self.create_channel()
        await self.create_topic(self.topic_name)
        await self.create_queue(self.queue_name)
        await self.bind_route_key(self.topic_name, self.subscribe_list)

        if self.publish_config_data:
            publish_key = 'new_subscriber_online'
            await self.bind_route_key(self.topic_name, [publish_key])

    async def send_subscribe_key_list_to_publisher(self):
        # send subscribe key list to publisher when app starts
        from aio_pika import Message, DeliveryMode

        if not self.topic_name:
            get_logger().warn('send subscribe key list failed because of organization code is None')
            return

        if self.subscribe_list:
            # if self.subscribe_list and not self.queue.declaration_result.message_count:
            msg = {'key': 'new_subscriber_online', 'data': self.subscribe_list}
            exchange = await self.get_topic(self.topic_name)
            message_body = json.dumps(msg).encode('utf-8')
            message = Message(message_body, delivery_mode=DeliveryMode.PERSISTENT)
            await exchange.publish(message, routing_key='new_subscriber_online')
            get_logger().info('send subscribe key list to publisher success ==%s', self.subscribe_list)

    async def publish_message(self, msg, time_series_data=False):
        # publish publish_key messages with topic exchange to queues,store the message if publish failed
        # msg格式：{'key':opc_data,'data':[]}
        from aio_pika import Message, DeliveryMode

        topic_name = get_organization()
        publish_key = msg.get('key')
        publish_data = msg.get('data')
        self.publish_message_cache.update({publish_key: publish_data})

        if self.connection:
            exchange = await self.get_topic(topic_name)
            message_body = json.dumps(msg).encode('utf-8')
            message = Message(message_body, delivery_mode=DeliveryMode.PERSISTENT)
            await exchange.publish(message, routing_key=publish_key)
            get_logger().info('publish key[%s] message success', publish_key)
        else:
            await self.persist_publish_failed_message(msg, time_series_data)
            get_logger().info('publish key[%s] message failed because connection is None', publish_key)

    async def create_queue(self, queue_name):
        # create a queue if not exist
        # 目前一个app对应一个queue
        if self.channel and queue_name:
            self.queue = await self.channel.declare_queue(queue_name, durable=True)
            get_logger().info('create queue:[%s] success', queue_name)

    async def bind_route_key(self, topic_name, subscribe_key_list):
        # bind queue and exchange with route_key
        if not topic_name:
            get_logger().warn('bind route key failed because of organization code is None')
            return

        exchange = await self.get_topic(topic_name)
        if self.queue:
            for subscribe_key in subscribe_key_list:
                await self.queue.bind(exchange, routing_key=subscribe_key)
                get_logger().info('bind subscribe key[%s] to topic[%s] success', subscribe_key, topic_name)

    async def listening_message(self):
        # listening message from the queue
        from aio_pika import IncomingMessage
        async def receive_message_callback(message: IncomingMessage):
            # receive_message is the message coming call_back func
            with message.process(ignore_processed=True):
                message.ack()
                topic_name = message.exchange
                routing_key = message.routing_key

                if routing_key != 'new_subscriber_online' and routing_key not in self.subscribe_list:
                    await self.queue.unbind(topic_name, routing_key)
                    get_logger().info('subscribe_key[%s] not exist in subscribe_list,unbind it to topic[%s]',
                                      routing_key, topic_name)
                    return

                message_body = json.loads(message.body.decode("utf-8"))
                get_logger().debug('receive rabbitmq message from topic[%s] by routing_key[%s]', topic_name, routing_key)
                get_logger().debug('message_body==%s', message_body)

                message = await self.check_message_format(message_body, routing_key)
                processed_message = await self.process_subscribe_message_cache(message)
                if processed_message:
                    await self.exectue_messsge_process_func(processed_message)

        if self.queue:
            await self.queue.consume(receive_message_callback)

    async def exectue_messsge_process_func(self, processed_message):
        if self.messsge_process_func:
            if iscoroutinefunction(self.messsge_process_func):
                await self.messsge_process_func(processed_message)
            else:
                self.messsge_process_func(processed_message)

    async def check_message_format(self, message_body, routing_key):
        # ensure message format is {'key':'','data':''}
        if isinstance(message_body, dict):
            if 'key' not in message_body.keys():
                message_body = {'key': routing_key, 'data': message_body}
        else:
            message_body = {'key': routing_key, 'data': message_body}

        return message_body

    async def process_subscribe_message_cache(self, message):
        # refresh subscribe message cache , and then process message
        message_key = message.get('key')
        message_data = message.get('data')
        if self.publish_config_data:
            if message_key == 'new_subscriber_online':
                get_logger().info('receive list new subscriber key_list==%s', message_data)
                for subscribe_key in message_data:
                    data = self.publish_message_cache.get(subscribe_key)
                    if data is not None:
                        msg = {'key': subscribe_key, 'data': data}
                        await self.publish_message(msg)
                    else:
                        get_logger().info('cannot publish subscribe key[%s] because publish message cache data is None',
                                          subscribe_key)
                return None

        cache_message_data = self.subscribe_message_cache.get(message_key)
        if json.dumps(message_data) != json.dumps(cache_message_data):
            self.subscribe_message_cache.update({message_key: message_data})
            await self.persist_subscribe_message_cache()
            return message  # 如果订阅到的消息和缓存里的消息不同则直接处理
        else:
            return None  # 如果订阅到的消息和缓存里的消息相同则忽略

    def on_connection_closed(self, future):
        try:
            future.result()
        except:
            self.connection = None
            self.channel = None
            self.queue = None
            self.topic = {}
            set_handler(TaskKey.rabbitmq_async, self)
            ioloop = IOLoop.current()
            ioloop.spawn_callback(self._reconnect)

    async def _reconnect(self):
        __cnt = 0
        while not self.connection:
            if await self.get_connection():
                set_handler(TaskKey.rabbitmq_async, self)
                await self.init_topic_and_queue()
                await self.listening_message()
                await self.republish_persist_message()
                break
            else:
                __cnt += 1
                get_logger().error('rabbitmq async reconnect number: ' + str(__cnt))
                await gen.sleep(self.reconnect_interval)

    async def persist_subscribe_message_cache(self):
        # persist subscribe message when receive from rabbitmq server
        if self.local_mongodb_connection is None:
            return

        db_connection = self.local_mongodb_connection
        db_name = 'rabbitmq_lib_' + get_uuid()
        db_handle = db_connection[db_name]
        from pymongo import DeleteMany, UpdateOne
        db_requests = [DeleteMany({'key': 'subscribe_message'}),
                       UpdateOne({'key': 'subscribe_message'}, {'$set': {'data': self.subscribe_message_cache}},
                                 upsert=True)]
        await db_handle.subscribe_message.bulk_write(db_requests)

    async def read_persist_subscribe_message(self):
        if self.local_mongodb_connection is None:
            return

        db_connection = self.local_mongodb_connection
        db_name = 'rabbitmq_lib_' + get_uuid()
        db_handle = db_connection[db_name]
        async for document in db_handle.subscribe_message.find(projection={'_id': False}):
            self.subscribe_message_cache = document['data']
            for message_key, message_data in self.subscribe_message_cache.items():
                message = {'key': message_key, 'data': message_data}
                await self.exectue_messsge_process_func(message)

        await db_handle.subscribe_message.drop()

    async def persist_publish_failed_message(self, message, time_series_data=False):
        # persist message when send it to rabbitmq server failed
        if self.local_mongodb_connection is None:
            return

        db_connection = self.local_mongodb_connection
        db_name = 'rabbitmq_lib_' + get_uuid()
        db_handle = db_connection[db_name]

        if time_series_data:
            await db_handle.publish_failed_time_series_data.insert_one(message)
        else:
            latest_data = await db_handle.publish_failed_latest_data.find_one_and_delete({}, projection={'_id': False})
            if latest_data is None:
                await db_handle.publish_failed_latest_data.insert_one({message.get('key'): message.get('data')})
            else:
                latest_data.update({message.get('key'): message.get('data')})
                await db_handle.publish_failed_latest_data.insert_one(latest_data)

    async def republish_persist_message(self):
        # once reconnect success, republish persist message in mongodb when rabbitmq server shutdown
        if self.local_mongodb_connection is None:
            return

        db_connection = self.local_mongodb_connection
        db_name = 'rabbitmq_lib_' + get_uuid()
        db_handle = db_connection[db_name]

        async for data in db_handle.publish_failed_time_series_data.find(projection={'_id': False}):
            await self.publish_message(data, time_series_data=True)
        await db_handle.publish_failed_time_series_data.drop()

        async for publish_failed_latest_data in db_handle.publish_failed_latest_data.find(projection={'_id': False}):
            for key_name, message_data in publish_failed_latest_data.items():
                msg = {'key': key_name, 'data': message_data}
                await self.publish_message(msg)
        await db_handle.publish_failed_latest_data.drop()

        get_logger().info('publish failed_message_cache success')

    async def connect_to_local_mongodb(self):
        try:
            from motor.motor_tornado import MotorClient
            self.local_mongodb_connection = MotorClient('127.0.0.1')
        except Exception as e:
            get_logger().debug(e)
            get_logger().warn('persistence function cannot used beacuse of connecting to local mongod service failed')

    # get message and then confirm message
    # incoming_message = await queue.get(timeout=5)
    # incoming_message.ack()


async def rabbitmq_publish_many(datas, time_series_data=False):
    # datas format:
    # [
    # {
    #     'key': 'opc_data_etl',
    #     'data': {
    #         'directory_code': 'opc_data_etl',
    #         'directory_name': 'opc数据采集',
    #         'children': []
    #     }
    # },{
    #     'key': 'assay_data_etl',
    #     'data': {
    #         'directory_code': 'assay_data_etl',
    #         'directory_name': '化验数据采集',
    #         'children': []
    #     }
    # }
    # ...
    # ]

    rabbitmq_handler = get_handler(TaskKey.rabbitmq_async)
    for data in datas:
        await rabbitmq_handler.publish_message(data, time_series_data)


async def rabbitmq_publish_one(data, time_series_data=False):
    # data format:
    # {
    #   'key': 'assay_data_etl',
    #     'data': {
    #         'directory_code': 'assay_data_etl',
    #         'directory_name': '化验数据采集',
    #         'children': []
    #     }
    # }

    rabbitmq_handler = get_handler(TaskKey.rabbitmq_async)
    await rabbitmq_handler.publish_message(data, time_series_data)


class RabbitMQConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


async def rabbitmq_async_connect(conn_time=None):
    __cnt = 0
    while True:
        if conn_time and __cnt == int(conn_time):
            get_logger().error(
                'rabbitmq async connect error,connect more than ' + str(conn_time) + ' times')
            raise RabbitMQConnectError
        store = Store.get_init_task_config(TaskKey.rabbitmq_async)
        host = store.get_rabbitmq_host()
        port = int(store.get_rabbitmq_port())
        username = store.get_rabbitmq_username()
        password = store.get_rabbitmq_password()
        publish_config_data = store.publish_config_data()
        subscribe_list = store.get_rabbitmq_subscribe_list()
        topic_name = get_organization()
        queue_name = get_uuid()
        message_process_func = store.messsge_process_func()
        reconnect_interval = store.reconnect_interval()
        rabbitmq_handler = RabbitMQClient(host, port, username, password, topic_name, queue_name, subscribe_list,
                                          publish_config_data, reconnect_interval, message_process_func)

        await rabbitmq_handler.connect_to_local_mongodb()
        await rabbitmq_handler.read_persist_subscribe_message()
        await rabbitmq_handler.get_connection()  # create conntion
        if rabbitmq_handler.connection:
            await rabbitmq_handler.init_topic_and_queue()
            await rabbitmq_handler.listening_message()
            await rabbitmq_handler.send_subscribe_key_list_to_publisher()
            set_handler(TaskKey.rabbitmq_async, rabbitmq_handler)
            start_next_task(TaskKey.rabbitmq_async)
            break
        else:
            __cnt += 1
            get_logger().exception('rabbitmq async connecting retry number: ' + str(__cnt))
            store = Store.get_init_task_config(TaskKey.rabbitmq_async)
            await gen.sleep(store.reconnect_interval())