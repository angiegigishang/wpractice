import json,datetime
from abc import ABCMeta, abstractmethod
from tornado.ioloop import IOLoop
from tornado import gen
from mg_app_framework.config import Store, get_logger, set_handler, get_handler, get_uuid, get_organization
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task
from inspect import iscoroutinefunction


class RedisConfigBasic(metaclass=ABCMeta):
    @abstractmethod
    def get_redis_host(self):
        pass

    @abstractmethod
    def get_redis_port(self):
        pass

    @abstractmethod
    def get_redis_username(self):
        pass

    @abstractmethod
    def get_redis_password(self):
        pass

    def reconnect_interval(self):
        """
        :return:重连redis时间间隔, 默认 5 秒

        """
        return 5


class RedisClient:
    def __init__(self, host, port, username, password, organization_name, reconnect_interval):

        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.organization_name = organization_name
        self.connection = None
        self.reconnect_interval = reconnect_interval

    async def get_connection(self):
        # get redis connection ,if not exist create one
        from aioredis import create_redis

        if not self.connection:
            try:
                self.connection = await create_redis(('localhost', 6379))
                get_logger().info('connect redis success')
            except Exception as e:
                print(e)
                get_logger().error('connect redis failed, [host=%s],[port=%s],[username=%s],[password=%s]',
                                   self.host, self.port, self.username, self.password)
        return self.connection

    async def redis_find(self, code_name, start_time, end_time):

        query_para = {
            'code': 'opc_code1',
            'start_time': "2019-01-01 15:32:00",
            'end_time': "2019-03-17 16:13:00"
        }

        result = {}

        if self.connection:
            key_name = self.get_key_name(code_name)
            start_time = string_timestamp_to_float_timestamp(start_time)
            end_time = string_timestamp_to_float_timestamp(end_time)
            res = await self.connection.zrangebyscore(key_name, start_time, end_time, encoding="utf-8")
            print(type(res[0]))
            print('result:',res)
            for time_and_value in res:
                time,value = time_and_value.split('!', 1)
                result.update({time:value})

        return result


    async def get_key_time_range(self,key_name):
        # get start time and end time of the key
        member_num = await self.connection.zcount(key_name)
        print('member_num',member_num)

        if member_num:
            start_time_and_value = await self.connection.zrange(key_name, 0, 0, encoding="utf-8")
            start_time = start_time_and_value[0].split('!',1)[0]
            print('start time:',start_time)

            end_time_and_value = await self.connection.zrange(key_name, member_num-1, member_num-1, encoding="utf-8")
            end_time = end_time_and_value[0].split('!',1)[0]
            print('end_time:',end_time)

            return [start_time,end_time]

    def get_key_name(self,code_name):
        if self.organization_name:
            key_name = self.organization_name + '_' + code_name
        else:
            key_name = code_name
        return key_name

async def redis_insert_one(organization_name,data):
    # data format is {'code':'opc_code1','timestamp':'2019-02-01 12:00:00','value':888}
    redis_handle = get_handler(TaskKey.redis_async)
    if redis_handle.connection:
        code_name = data.get('code')
        str_time = data.get('timestamp')
        value = data.get('value')
        member_name = str_time + '!' + str(value)
        float_timestamp = string_timestamp_to_float_timestamp(str_time)
        key_name = organization_name + '_' + code_name
        print(key_name)
        await redis_handle.connection.zadd(key_name, float_timestamp, member_name)
        get_logger().debug('insert data to redis successs==%s',data)


async def redis_insert_many(datas):
    # datas format
    # {
    #     'organization_kmly': [{
    #         'timestamp': '2018-12-0717: 50: 49',
    #         'code': 'opc_cn_xs',
    #         'value': 0，
    #         'type': 'kpi_lab_from_idi'
    #     },
    #         {
    #             'timestamp': '2018-12-0717: 50: 49',
    #             'code': 'opc_cj_db_1',
    #             'value': 0，
    #             'type': 'kpi_lab_from_idi'
    #         }],
    #     'organization_fsly': [{
    #         'timestamp': '2018-12-0717: 50: 49',
    #         'code': 'opc_cn_xs',
    #         'value': 0，
    #         'type': 'kpi_lab_from_idi'
    #     },
    #         {
    #             'timestamp': '2018-12-0717: 50: 49',
    #             'code': 'opc_cj_db_1',
    #             'value': 0，
    #             'type': 'kpi_lab_from_idi'
    #         }]
    # }
    for organization_name,data_list in datas.items():
        for data in data_list:
            await redis_insert_one(organization_name,data)


def string_timestamp_to_float_timestamp(string_time):
    if isinstance(string_time, str):
        float_time = datetime.datetime.strptime(string_time, "%Y-%m-%d %H:%M:%S").timestamp()
        return float_time
    else:
        raise TypeError("timestamp must be string")


class RedisConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


async def redis_async_connect(conn_time=None):
    __cnt = 0
    while True:
        if conn_time and __cnt == int(conn_time):
            get_logger().error(
                'redis async connect error,connect more than ' + str(conn_time) + ' times')
            raise RedisConnectError
        store = Store.get_init_task_config(TaskKey.redis_async)
        organization_name = get_organization()
        host = store.get_redis_host()
        port = int(store.get_redis_port())
        username = store.get_redis_username()
        password = store.get_redis_password()
        reconnect_interval = store.reconnect_interval()
        redis_handler = RedisClient(host, port, username, password, organization_name,reconnect_interval)

        await redis_handler.get_connection()  # create conntion
        if redis_handler.connection:
            set_handler(TaskKey.redis_async, redis_handler)
            start_next_task(TaskKey.redis_async)
            break
        else:
            __cnt += 1
            get_logger().exception('redis async connecting retry number: ' + str(__cnt))
            store = Store.get_init_task_config(TaskKey.redis_async)
            await gen.sleep(store.reconnect_interval())
