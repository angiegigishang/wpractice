from mg_app_framework.config import Store, get_logger
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task
from abc import ABCMeta, abstractmethod
from inspect import iscoroutinefunction


class InitFuncBasic(metaclass=ABCMeta):
    @abstractmethod
    async def init_func(self):
        pass


async def run_userdef():
    try:
        store = Store.get_init_task_config(TaskKey.init_func)
        init_def = store.init_func
        if iscoroutinefunction(init_def):
            await init_def()
        else:
            init_def()
        start_next_task(TaskKey.init_func)
    except Exception as e:
        get_logger().exception(e)
