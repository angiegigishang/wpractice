from tornado.ioloop import IOLoop
import tornado.autoreload

from mg_app_framework.config import Store, update_context
from mg_app_framework.components import TaskKey, TASKS


def app_start(debug=True):
    admin_task = TASKS[TaskKey.admin]

    loop = IOLoop.current()
    Store.set_loop(loop)
    Store.set_tasks(TASKS)
    update_context('debug_flag', debug)

    loop.spawn_callback(admin_task, re_conn=False, conn_time=3, debug=debug)

    # 判断是否需要热加载(本地启动或者debug模式下需要热加载)
    if debug:
        tornado.autoreload.start()

    loop.start()
