import os
import tornado.ioloop
import tornado.web
import tornado.websocket
import json
from os.path import basename, dirname, join, exists

from mg_app_framework.config import Store, get_ha_role, get_logger, get_uuid
from mg_app_framework.message import MesCode
from mg_app_framework.components import TaskKey
from mg_app_framework.client import HttpClient
import urllib


class DataTypeError(Exception):
    pass


# 文件流(http下载模块用)
class FileStream:

    def __init__(self, filename):
        self.filename = filename

    def send(self, buf_size, http_handler):
        with open(self.filename, 'rb') as f:
            while True:
                data = f.read(buf_size)
                if not data:
                    break
                http_handler.write(data)


# 字节流(http下载模块用)
class BufferStream:

    def __init__(self, data):
        self.data = data

    def send(self, buf_size, http_handler):
        start_num = 0
        while True:
            data = self.data[start_num:start_num + buf_size]
            if not data:
                break
            http_handler.write(data)
            start_num += buf_size


class HttpBasicHandler(tornado.web.RequestHandler):
    def set_default_headers(self):
        cross_domain = Store.store.cross_domain()
        # 根据是否跨域 设置http header
        if cross_domain:
            # self.set_header("Access-Control-Allow-Origin", "*")
            self.set_header("Access-Control-Expose-Headers", "Content-Disposition")
            self.set_header("Access-Control-Allow-Origin", self.request.headers["Origin"])
            self.set_header('Access-Control-Allow-Credentials', "true")
        else:
            self.set_header("Access-Control-Allow-Origin", "*")
            self.set_header("Access-Control-Expose-Headers", "Content-Disposition")
            # self.set_header("Access-Control-Allow-Origin", self.request.headers["Origin"])
            # self.set_header('Access-Control-Allow-Credentials', "true")

    @property
    def data(self):
        # 获取url 和 body中的参数
        argument_data = dict()
        a = self.request.query_arguments
        for i in a.keys():
            argument_data[i] = self.get_argument(i)
        if self.request.body:
            body_data = json.loads(self.request.body.decode('utf-8'))
            if isinstance(body_data, dict):
                body_data.update(argument_data)
                return body_data
            else:
                get_logger().exception('body data is not a dict')
                raise DataTypeError
        else:
            return argument_data

    @property
    async def login_name(self):
        try:
            login_name = self.get_cookie('login_name')
            if login_name:
                return login_name
            else:
                if self.request.body:
                    body_data = json.loads(self.request.body.decode('utf-8'))
                    if 'manugence_login_name' in body_data:
                        return body_data['manugence_login_name']
                    else:
                        return None
                else:
                    return None
        except Exception as e:
            get_logger().exception('get login_name fail')
            return None

    @property
    async def login_organization(self):
        try:
            login_organization = self.get_cookie('login_organization')
            if login_organization:
                return login_organization
            else:
                if self.request.body:
                    body_data = json.loads(self.request.body.decode('utf-8'))
                    if 'manugence_login_organization' in body_data:
                        return body_data['manugence_login_organization']
                    else:
                        return None
                else:
                    return None
        except Exception as e:
            get_logger().exception('get login_organization fail')
            return None

    @property
    async def login_role(self):
        cookie_login_uuid = self.get_cookie('login_uuid')
        login_uuid = None
        if cookie_login_uuid:
            login_uuid = cookie_login_uuid
        else:
            if self.request.body:
                body_data = json.loads(self.request.body.decode('utf-8'))
                if 'manugence_login_uuid' in body_data:
                    login_uuid = body_data['manugence_login_uuid']
        if login_uuid:
            login_url = Store.get_login_url()
            client = HttpClient()
            get_login_role_url = login_url + '/api/auth/user_role'

            post_data = {
                'login_uuid': str(login_uuid)
            }
            res = await client.post(get_login_role_url, data=post_data)
            res_code = res.code
            if res_code == MesCode.success:
                res_data = res.data
                user_role = res_data['user_role']
                # super_admin or role
                return user_role
            else:
                get_logger().error('get role fail')
        else:
            get_logger().error('cookie login_uuid is None')

    def _set_response_data(self, result):
        try:
            self.finish(json.dumps(result, ensure_ascii=False))
        except Exception as e:
            self.finish(json.dumps(
                {"code": MesCode.fail, "info": str(e)}))

    async def get_process(self, *args, **kwargs):
        pass

    async def post_process(self, *args, **kwargs):
        pass

    async def delete_process(self, *args, **kwargs):
        pass

    async def put_process(self, *args, **kwargs):
        pass

    async def _process(self, method_process, *args, **kwargs):
        result = dict()
        result['app_group'] = Store.get_app_group()
        result['app_name'] = Store.get_app_name()
        try:
            await method_process(*args, **kwargs)
        except Exception as e:
            get_logger().error(str(e))
            result["code"] = MesCode.fail
            result["data"] = None
            result["info"] = str(e)
            self._set_response_data(result)

    def send_response_data(self, code, data=None, info=None):
        result = dict()
        result['app_group'] = Store.get_app_group()
        result['app_name'] = Store.get_app_name()
        if code == MesCode.success or code == MesCode.fail or code == MesCode.login:
            result["code"] = code
            result["data"] = data
            result["info"] = info
            self._set_response_data(result)
        else:
            get_logger().exception('HTTP return code is wrong')

    # http 下载接口
    def send_response_file(self, filename=None, data=None, buf_size=1024):
        self.set_header('Content-Type', 'application/octet-stream')
        self.set_header('Content-Disposition', 'attachment; filename=%s; filename*=%s' %
                        (urllib.parse.quote(filename), urllib.parse.quote(filename)))
        try:
            data.send(buf_size, self)
        except Exception:
            get_logger().exception('send_response_file data send wrong')
            get_logger().exception('data type = ' + str(type(data)))
        self.finish()

    async def get(self, *args, **kwargs):
        await self._process(self.get_process, *args, **kwargs)

    async def post(self, *args, **kwargs):
        await self._process(self.post_process, *args, **kwargs)

    async def put(self, *args, **kwargs):
        await self._process(self.put_process, *args, **kwargs)

    async def delete(self, *args, **kwargs):
        await self._process(self.delete_process, *args, **kwargs)


class HttpBasicCookieHandler(HttpBasicHandler):
    def set_default_headers(self):
        # self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header("Access-Control-Expose-Headers", "Content-Disposition")
        self.set_header("Access-Control-Allow-Origin", self.request.headers["Origin"])
        self.set_header('Access-Control-Allow-Credentials', "true")


class SetCookieHandler(HttpBasicCookieHandler):

    async def post_process(self):

        try:
            require_data = self.data
            login_uuid = require_data['login_uuid']
            login_name = require_data['login_name']
            get_logger().info('set login cookie login_uuid == ' + str(login_uuid))
            get_logger().info('set login cookie login_name == ' + str(login_name))
            if 'login_organization' in require_data:
                login_organization = require_data['login_organization']
                get_logger().info('set login cookie login_organization == ' + str(login_organization))
                self.set_cookie('login_organization', str(login_organization), expires_days=1,
                                domain=None)
            if login_uuid and login_name:
                self.set_cookie('login_uuid', str(login_uuid), expires_days=1,
                                domain=None)
                self.set_cookie('login_name', str(login_name), expires_days=1,
                                domain=None)
                # self.set_cookie('login_organization', str(login_organization), expires_days=1,
                #                 domain=None)
                self.send_response_data(MesCode.success, None, 'cookie设置成功')
            else:
                self.send_response_data(MesCode.fail, None, 'cookie设置失败, 不能为None')
        except Exception as e:
            get_logger().info(str(e))
            self.send_response_data(MesCode.fail, None, 'cookie设置失败')


class WebsocketBasicHandler(tornado.websocket.WebSocketHandler):
    def check_origin(self, origin):
        return True

    @property
    async def login_name(self):
        try:
            login_name = self.get_cookie('login_name')
            if login_name:
                return login_name
            else:
                return None
        except Exception as e:
            get_logger().exception('get login_name fail')
            return None

    @property
    async def login_organization(self):
        try:
            login_organization = self.get_cookie('login_organization')
            if login_organization:
                return login_organization
            else:
                return None
        except Exception as e:
            get_logger().exception('get login_organization fail')
            return None

    # @property
    # async def login_organization(self):
    #     cookie_login_uuid = self.get_cookie('login_uuid')
    #     login_uuid = None
    #     if cookie_login_uuid:
    #         login_uuid = cookie_login_uuid
    #     if login_uuid:
    #         login_url = Store.get_login_url()
    #         client = HttpClient()
    #         get_login_organization_url = login_url + '/api/auth/user_organization'
    #         post_data = {
    #             'login_uuid': str(login_uuid)
    #         }
    #         res = await client.post(get_login_organization_url, data=post_data)
    #         res_code = res.code
    #         if res_code == MesCode.success:
    #             res_data = res.data
    #             user_factory = res_data['user_organization']
    #             # ALL  or  factory
    #             return user_factory
    #         else:
    #             get_logger().error('get login_organization fail')
    #             return None
    #     else:
    #         get_logger().error('cookie login_uuid is None')
    #         return None

    @property
    async def login_role(self):
        cookie_login_uuid = self.get_cookie('login_uuid')
        login_uuid = None
        if cookie_login_uuid:
            login_uuid = cookie_login_uuid
        if login_uuid:
            login_url = Store.get_login_url()
            client = HttpClient()
            get_login_role_url = login_url + '/api/auth/user_role'

            post_data = {
                'login_uuid': str(login_uuid)
            }
            res = await client.post(get_login_role_url, data=post_data)
            res_code = res.code
            if res_code == MesCode.success:
                res_data = res.data
                user_role = res_data['user_role']
                #super_admin or role
                return user_role
            else:
                get_logger().error('get role fail')
        else:
            get_logger().error('cookie login_uuid is None')


def _get_urls_file(path, apps_url, module_url):
    try:
        for filename in os.listdir(path):
            full_path = os.path.join(path, filename)
            if os.path.isdir(full_path):
                _get_urls_file(full_path, apps_url, module_url)
            elif filename == 'urls.py':
                apps_url += getattr(
                    __import__((module_url + path.split(module_url)[1] + '/urls').replace('/', '.'),
                               fromlist=['url']), 'url')
    except Exception as e:
        get_logger().exception(e)


def _get_app_urls():
    app_urls = []
    module_dir = Store.get_module_dir()
    handlers_dir = join(module_dir, 'handlers')
    if exists(handlers_dir):
        module_name = basename(module_dir)
        _get_urls_file(handlers_dir, app_urls, module_name + '/handlers')
        if len(app_urls) > 0:
            app_urls += [
                (r'/api/auth/set_cookie', SetCookieHandler)
            ]

    app_urls = _check_ha_url(app_urls)
    app_urls = _check_sds_url(app_urls)

    return app_urls


def _check_ha_url(url):
    from mg_app_framework.components.ha import HaWebHandler
    init_keys = Store.get_init_task_keys()
    if TaskKey.ha in init_keys and get_ha_role() is not None:
        url += [
            (r'/ha_connect_url', HaWebHandler),
        ]
    return url


def _check_sds_url(url):
    from mg_app_framework.components.sds import is_sds_enabled, get_app_online_url, get_app_msg_url
    # Enabled SDS
    if is_sds_enabled():
        url += get_app_online_url()
        url += get_app_msg_url()

    return url


def make_process_app():
    app_urls = _get_app_urls()
    if len(app_urls) > 0:
        app = tornado.web.Application(app_urls)
        app.listen(Store.get_app_port(), address=Store.get_app_ip())


def make_user_app():
    static_dir = join(dirname(dirname(Store.get_module_dir())), 'static', 'dist')

    app_urls = _get_app_urls()
    app_urls += [
        (r'/(.*)', tornado.web.StaticFileHandler, {'path': static_dir, 'default_filename': "index.html"}),
    ]
    app = tornado.web.Application(app_urls)
    app.listen(Store.get_app_port(), address=Store.get_app_ip())
