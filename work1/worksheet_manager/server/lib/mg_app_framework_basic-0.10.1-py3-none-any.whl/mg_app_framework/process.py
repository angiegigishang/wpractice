import json
from tornado import gen

from mg_app_framework.config import Store, AppType, get_handler, set_handler, get_context, get_logger, get_ha_role, \
    AppHaRole, LogLevel
from mg_app_framework.message import MesType, send_mes, HaMesType, send_ha_mes
from mg_app_framework.components import TaskKey
from mg_app_framework.scheduler import update_scheduler
from mg_app_framework.scheduler import make_scheduler
from mg_app_framework.web import make_process_app, make_user_app
import logging


# 监听接收manager消息函数
async def app_config_process():
    while True:
        config_func = Store.get_config_func()
        logger = get_logger()
        admin_handler = get_handler(TaskKey.admin)
        try:
            message_str = await admin_handler.read_message()
            if message_str:
                message = json.loads(message_str)
                if message['type'] == MesType.update_config:
                    logger.info('configuration before updating: ' + str(Store.get_data()))
                    if message['info'] == 'init_recover':
                        check_ha_result = check_ha(message)
                        if check_ha_result:
                            Store.update_data(message['data'])
                        else:
                            Store.store.get_data().update({'online': True})
                    else:
                        Store.update_data(message['data'])

                    if 'log_level' in message['data']:
                        log_level = message['data']['log_level']
                        if log_level == LogLevel.DEBUG:
                            get_logger().setLevel(logging.DEBUG)
                        elif log_level == LogLevel.INFO:
                            get_logger().setLevel(logging.INFO)
                        elif log_level == LogLevel.WARN:
                            get_logger().setLevel(logging.WARN)
                        elif log_level == LogLevel.ERROR:
                            get_logger().setLevel(logging.ERROR)

                    logger.info('configuration after updating: ' + str(message['data']))

                    scheduler = get_context('scheduler')
                    if scheduler:
                        if Store.get_switch():
                            scheduler.resume()
                        else:
                            scheduler.pause()
                        update_scheduler()
                    await send_mes(admin_handler, MesType.update_config, Store.get_data())
                    ha_role = get_ha_role()
                    if ha_role and ha_role == AppHaRole.master:
                        await send_ha_mes(HaMesType.ha_auto_update, Store.get_data())
                await config_func()
            else:
                logger.warning('websocket broken link')
                admin_connect = Store.get_tasks()[TaskKey.admin]
                admin_handler = await admin_connect()
                set_handler(TaskKey.admin, admin_handler)
        except Exception as e:
            logger.exception(str(e))
            app_type = Store.get_app_type()
            if app_type == AppType.interval or app_type == AppType.cron or app_type == AppType.date:
                Store.set_switch(False)
                logger.exception('switch turning off')
                await send_mes(admin_handler, MesType.alarm, info='switch turning off')
            await gen.sleep(5)


def check_ha(message):
    # my_role
    my_role = get_ha_role()
    if my_role:
        # update_role
        try:
            update_role = message['data']['data']['config_data']['ha_settings']['group_member']['ha_role']['value']
        except Exception:
            update_role = None
        if update_role:
            if my_role == AppHaRole.follower and update_role == AppHaRole.follower:
                # 以HA Master同步过来的配置为准
                ha_other_side_role = get_context('ha_other_side_role')
                if ha_other_side_role:
                    return False
            elif my_role == AppHaRole.follower and update_role == AppHaRole.master:
                ha_other_side_role = get_context('ha_other_side_role')
                if ha_other_side_role == AppHaRole.master:
                    return False
            elif my_role == AppHaRole.master and update_role == AppHaRole.follower:
                ha_other_side_role = get_context('ha_other_side_role')
                if not ha_other_side_role:
                    return False
                elif ha_other_side_role == AppHaRole.follower:
                    return False
    return True


async def websocket_process():
    try:
        websocket_handler_dict = get_handler(TaskKey.websocket)
        for websocket_name, websocket_handler in websocket_handler_dict.items():
            websocket_handler.receive_cycle()
    except Exception as e:
        logger = get_logger()
        logger.exception("websocket receive_cycle error:%s" % str(e))


# 运行下一步初始化
def start_next_task(now_task):
    init_keys = Store.get_init_task_keys()
    init_keys_list = list(init_keys)
    init_keys_list_len = len(init_keys_list)
    loop = Store.get_loop()

    if now_task in init_keys_list:
        now_task_index = init_keys_list.index(now_task)
        # 判断当前运行到初始化哪一步，并找到下一步开始初始化
        if now_task_index + 1 < init_keys_list_len:
            next_task_index = now_task_index + 1
            next_task_key = init_keys_list[next_task_index]
            tasks = Store.get_tasks()
            next_task = tasks[next_task_key]
            if next_task_key == TaskKey.init_func:
                loop.spawn_callback(next_task)
            elif next_task_key == TaskKey.websocket or next_task_key == TaskKey.sds or \
                    next_task_key == TaskKey.ha or next_task_key == TaskKey.idi or \
                    next_task_key == TaskKey.rabbitmq_async or next_task_key == TaskKey.redis_async:
                loop.spawn_callback(next_task, conn_time=3)
            else:
                loop.spawn_callback(next_task, re_conn=False, conn_time=3)
        else:
            # 所有初始化完成后，开启定时逻辑
            make_scheduler()
            debug_flag = get_context('debug_flag')
            # 开启监听接收manager 消息逻辑
            if debug_flag:
                connect_admin = Store.store.connect_admin()
                if connect_admin:
                    loop.spawn_callback(app_config_process)
            else:
                loop.spawn_callback(app_config_process)
            # 开启监听接收webscoket消息
            if TaskKey.websocket in init_keys_list:
                loop.spawn_callback(websocket_process)
            app_type = Store.get_app_type()
            # 开启http服务
            if app_type == AppType.user:
                make_user_app()
            else:
                make_process_app()
