from tornado.httpclient import AsyncHTTPClient, HTTPRequest, HTTPResponse
from urllib.parse import urlsplit
import json
import re

import urllib
import string

'''
在AsyncHTTPClient 基础上做了初步的封装便于调用，在实际应用中如果有需要进一步封装会持续跟进
'''


class Response(HTTPResponse):
    def __init__(self, response):
        self.response = response

    @property
    def body(self):
        body = self.response.body.decode("utf-8")
        return json.loads(body)

    @property
    def code(self):
        if 'code' in self.body:
            return self.body['code']
        else:
            return None

    @property
    def info(self):
        if 'info' in self.body:
            return self.body['info']
        else:
            return None

    @property
    def data(self):
        try:
            return self.body['data']
        except Exception as e:
            raise e


def _query_to_dict(query):
    try:
        query_list = re.split('&', query)
        return {query.split("=")[0]: query.split("=")[1]
                for query in query_list}
    except Exception as e:
        raise e


class HttpClient:
    def __init__(self, http_client=None):
        if http_client:
            self.cli = http_client
        else:
            self.cli = AsyncHTTPClient()

    async def _request(self, url, data={}, auth_username=None, auth_password=None, method="GET", headers=None, connect_timeout=20, request_timeout=20):
        url_split = urlsplit(url)
        if url_split.query:
            query_data = _query_to_dict(url_split.query)
            data.update(query_data)
        url = urllib.parse.quote(url, safe=string.printable)
        if " " in url:
            url = url.replace(" ", "%20")
        request = HTTPRequest(url, body=json.dumps(data), method=method, headers=headers,
                              auth_username=auth_username, auth_password=auth_password,
                              connect_timeout=connect_timeout, request_timeout=request_timeout,
                              allow_nonstandard_methods=True)

        res = await self.cli.fetch(request)
        return Response(res)

    async def get(self, url, data={}, auth_username=None, auth_password=None, client_self=None, headers=None, connect_timeout=20, request_timeout=20):
        if client_self:
            login_uuid = client_self.get_cookie('login_uuid')
            if login_uuid:
                data['manugence_login_uuid'] = login_uuid
            login_name = client_self.get_cookie('login_name')
            if login_name:
                data['manugence_login_name'] = login_name
            login_organization = client_self.get_cookie('login_organization')
            if login_organization:
                data['manugence_login_organization'] = login_organization
        return await self._request(url, data, auth_username, auth_password, "GET", headers, connect_timeout, request_timeout)

    async def post(self, url, data={}, auth_username=None, auth_password=None, client_self=None, headers=None, connect_timeout=20, request_timeout=20):
        if client_self:
            login_uuid = client_self.get_cookie('login_uuid')
            if login_uuid:
                data['manugence_login_uuid'] = login_uuid
            login_name = client_self.get_cookie('login_name')
            if login_name:
                data['manugence_login_name'] = login_name
            login_organization = client_self.get_cookie('login_organization')
            if login_organization:
                data['manugence_login_organization'] = login_organization
        return await self._request(url, data, auth_username, auth_password, "POST", headers, connect_timeout, request_timeout)

    async def put(self, url, data={}, auth_username=None, auth_password=None, client_self=None, headers=None, connect_timeout=20, request_timeout=20):
        if client_self:
            login_uuid = client_self.get_cookie('login_uuid')
            if login_uuid:
                data['manugence_login_uuid'] = login_uuid
            login_name = client_self.get_cookie('login_name')
            if login_name:
                data['manugence_login_name'] = login_name
            login_organization = client_self.get_cookie('login_organization')
            if login_organization:
                data['manugence_login_organization'] = login_organization
        return await self._request(url, data, auth_username, auth_password, "PUT", headers, connect_timeout, request_timeout)

    async def delete(self, url, data={}, auth_username=None, auth_password=None, client_self=None, headers=None, connect_timeout=20, request_timeout=20):
        if client_self:
            login_uuid = client_self.get_cookie('login_uuid')
            if login_uuid:
                data['manugence_login_uuid'] = login_uuid
            login_name = client_self.get_cookie('login_name')
            if login_name:
                data['manugence_login_name'] = login_name
            login_organization = client_self.get_cookie('login_organization')
            if login_organization:
                data['manugence_login_organization'] = login_organization
        return await self._request(url, data, auth_username, auth_password, "DELETE", headers, connect_timeout, request_timeout)

    def close(self):
        self.cli.close()


async def async_test():
    import time
    t = time.time()

    import urllib
    import string
    parameter = '测试样例'
    url_parameter = urllib.parse.quote(parameter)
    print(url_parameter)

    url = "http://192.168.20.186:8081/api/v1/idi/opc/history/tags"
    url = urllib.parse.quote(url, safe=string.printable)
    print(url)
    data = [{'code_name': 'opc_test1', 'start_time': "2018-09-17 11:12:00", 'end_time': "2018-09-17 11:16:00"},
            {'code_name': 'opc_test2', 'start_time': "2018-09-17 11:12:00", 'end_time': "2018-09-17 11:16:00"}]
    client = HttpClient()
    res = await client.get(url, data=data)
    data = res.data
    print(data)
    # body = res.body
    # code = res.code
    # await client.get(url, data=data)
    # # await client.put(url, data=data)
    # # await client.delete(url, data=data)

#
# async def async_websocket():
#     from datetime import datetime
#     url = "ws://127.0.0.1/websocket_url"
#     data = {"test": "websocket", "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
#     client = WebSocketClient(url)
#     await client.send(data)  # send message
#     conn = await client.get_client()  # get websocket connect
#     await client.receive_cycle(process_func)  # reveive data cycle


#
#
# async def process_func(data):
#     pass
#
#
if __name__ == "__main__":
    from tornado.ioloop import IOLoop

    io_loop = IOLoop.instance()
    # io_loop.run_sync(async_websocket)
    io_loop.run_sync(async_test)
    io_loop.start()
